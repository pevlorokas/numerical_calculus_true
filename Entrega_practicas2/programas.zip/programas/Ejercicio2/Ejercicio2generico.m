clc
close all
clear all
addpath('../biblioteca')






